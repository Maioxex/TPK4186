class move:
    def __init__(self, move, pliesChekced, time, player):
        self.move = move
        self.pliesChekced = pliesChekced
        self.time = time
        self.player = player